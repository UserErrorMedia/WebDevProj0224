The website is coded as one responsive landing page with an external link to a page with a contact form.

The "Home" and "About" options in the navigation bar are links to the main landing page contained in TechSolutions.html.
The "Contact" option as well as the "Sign Up" button are links to the Contact page contained in Contact.html

There are two javascript elements. The top navigation bar will collapse into a hamburger menu when the dimensions of the device are shrunken to mobile size. It operates on a "click" function and cascades from the top of the screen downwards. The second element is the hover animation for the "Get Started" button in the body section. This button will aslo take you to the Contact Page.

The Contact page only contains a contact form with a submit button (which has not been coded to send in an email at this time). The navigation bar on this page has been reduced to only one option which takes you back to the "Home" or main landing page.
 